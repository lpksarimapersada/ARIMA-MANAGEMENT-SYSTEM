# ARIMA MANAGEMENT SYSTEM — LPKS Arima Persada

## 1. Database
Spreadsheet ID is already hard-coded in `Config.gs`:
`1xm6FqlvKLi2a2WP0vy3qfjEbCz3CggZnMxc6GcvGaA4`

## 2. Upload
Create a new Google Apps Script project and add all `.gs` and `.html` files from this folder.
`logo.webp` is a preserved copy of the supplied logo; the web app embeds an optimized copy in `Settings.gs`, so no Drive hosting is required.

## 3. Setup
Run `setupDatabase()` once from Apps Script.
It creates/repairs missing sheets and headers without deleting existing data.

## 4. Create first admin
Run `createAdmin({userId:'ADMIN001', password:'GantiPasswordKuat!', name:'Administrator'})`
from the Apps Script editor, or use the spreadsheet menu after opening the spreadsheet:
ARIMA MANAGEMENT → Create/Reset Admin.

Do not use a weak production password.

## 5. Demo
Optional: run `seedDemoData()` only on a test database. It adds sample students, Sensei, class and schedule data if the student table is empty.

## 6. Deploy
Deploy → New deployment → Web app.
Execute as: Me.
Who has access: choose the audience appropriate for your organization.
After deployment, open the web app URL.

## 7. Important
This build uses Google Spreadsheet as the primary database and WhatsApp reminder links rather than an automated WhatsApp API. Automated WhatsApp sending can require a separate provider/API.

## 8. Modules
Authentication, Students, Sensei, Classes, Schedule, Attendance, Billing, Payments, Receipts, Payroll, Reports, Settings and Logs are separated into modular files.
