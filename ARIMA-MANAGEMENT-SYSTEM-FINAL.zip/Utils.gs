/**
 * Utility helpers.
 */
function now() {
  return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm:ss');
}

function todayISO() {
  return Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd');
}

function formatDateTime(value) {
  if (!value) return '';
  const d = value instanceof Date ? value : new Date(value);
  if (isNaN(d.getTime())) return String(value);
  return Utilities.formatDate(d, CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm:ss');
}

function formatDateOnly(value) {
  if (!value) return '';
  const d = value instanceof Date ? value : new Date(value);
  if (isNaN(d.getTime())) return String(value);
  return Utilities.formatDate(d, CONFIG.TIMEZONE, 'yyyy-MM-dd');
}

function formatRupiahServer(value) {
  const n = Number(value || 0);
  return 'Rp ' + Math.round(n).toLocaleString('id-ID');
}

function cleanNumber(value) {
  if (typeof value === 'number') return value;
  return Number(String(value || '').replace(/[^\d.-]/g,'')) || 0;
}

function sanitizeText(value) {
  return String(value == null ? '' : value).trim();
}

function parseDateInput(value) {
  if (!value) return '';
  if (value instanceof Date) return formatDateOnly(value);
  const s = String(value);
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const d = new Date(s);
  return isNaN(d.getTime()) ? '' : formatDateOnly(d);
}

function hashPassword(password, salt) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(salt) + String(password));
  return bytes.map(b => ('0' + (b & 0xFF).toString(16)).slice(-2)).join('');
}

function createSalt() {
  return Utilities.getUuid().replace(/-/g,'');
}

function randomToken() {
  return Utilities.getUuid().replace(/-/g,'') + Utilities.getUuid().replace(/-/g,'');
}

function getSetting(key) {
  const found = getAllRecords(CONFIG.SHEETS.SETTINGS).find(r => r.KEY === key);
  return found ? found.VALUE : '';
}

function setSetting(key, value, description) {
  const found = findById(CONFIG.SHEETS.SETTINGS,key,'KEY');
  if (found) {
    updateRowById(CONFIG.SHEETS.SETTINGS,key,'KEY',{VALUE:value,DESCRIPTION:description || found.data.DESCRIPTION,UPDATED_AT:now()});
  } else {
    appendRowObject(CONFIG.SHEETS.SETTINGS,{KEY:key,VALUE:value,DESCRIPTION:description || '',UPDATED_AT:now()});
  }
  return true;
}

function buildWaUrl(phone, message) {
  let p = String(phone || '').replace(/\D/g,'');
  if (p.startsWith('0')) p = '62' + p.slice(1);
  return 'https://wa.me/' + p + '?text=' + encodeURIComponent(message);
}

function logAction(user, action, module, referenceId, description) {
  appendRowObject(CONFIG.SHEETS.LOGS,{
    LOG_ID: generateId('LG',CONFIG.SHEETS.LOGS,'LOG_ID'),
    TIMESTAMP: now(),
    USER_ID: user ? user.USER_ID : '',
    USER_NAME: user ? user.NAME : 'SYSTEM',
    ROLE: user ? user.ROLE : 'SYSTEM',
    ACTION: action, MODULE: module, REFERENCE_ID: referenceId || '',
    DESCRIPTION: description || '', IP_INFO_IF_AVAILABLE:''
  });
}

function requireFields(obj, fields) {
  fields.forEach(f => {
    if (obj[f] === undefined || obj[f] === null || String(obj[f]).trim() === '') {
      throw new Error('Field wajib belum diisi: ' + f);
    }
  });
}

function sum(records, field) {
  return records.reduce((a,r)=>a+cleanNumber(r[field]),0);
}

function unique(arr) {
  return [...new Set(arr)];
}
