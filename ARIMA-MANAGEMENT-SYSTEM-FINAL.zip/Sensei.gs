/**
 * Sensei management.
 */
function getSensei(token, filters) {
  try {
    const user=requireAuth(token);
    let data=getAllRecords(CONFIG.SHEETS.SENSEI);
    if(user.ROLE===CONFIG.ROLES.SENSEI) data=data.filter(x=>x.SENSEI_ID===user.USER_ID);
    filters=filters||{};
    if(filters.status) data=data.filter(x=>x.STATUS===filters.status);
    if(filters.search){const q=String(filters.search).toLowerCase();data=data.filter(x=>[x.SENSEI_ID,x.NAMA,x.NO_WA,x.EMAIL].join(' ').toLowerCase().includes(q));}
    return {success:true,data};
  }catch(e){return {success:false,message:e.message};}
}

function getSenseiById(token,id){
  try{const user=requireAuth(token);if(user.ROLE===CONFIG.ROLES.SENSEI&&user.USER_ID!==id)throw new Error('Akses ditolak.');const rec=findById(CONFIG.SHEETS.SENSEI,id,'SENSEI_ID');return {success:true,data:rec?rec.data:null};}
  catch(e){return {success:false,message:e.message};}
}

function saveSensei(token,payload){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]); payload=payload||{}; requireFields(payload,['NAMA']);
    const id=sanitizeText(payload.SENSEI_ID).toUpperCase()||generateId(CONFIG.SENSEI_PREFIX,CONFIG.SHEETS.SENSEI,'SENSEI_ID');
    const existing=findById(CONFIG.SHEETS.SENSEI,id,'SENSEI_ID');
    const data={...payload,SENSEI_ID:id,TARIF_PER_JAM:cleanNumber(payload.TARIF_PER_JAM),TARIF_PER_PERTEMUAN:cleanNumber(payload.TARIF_PER_PERTEMUAN),STATUS:payload.STATUS||'AKTIF',UPDATED_AT:now()};
    if(existing){updateRowById(CONFIG.SHEETS.SENSEI,id,'SENSEI_ID',data);logAction(user,'UPDATE','SENSEI',id,'Data Sensei diperbarui');}
    else{data.CREATED_AT=now();appendRowObject(CONFIG.SHEETS.SENSEI,data);logAction(user,'CREATE','SENSEI',id,'Sensei baru ditambahkan');}
    return {success:true,message:'Data Sensei berhasil disimpan.'};
  }catch(e){return {success:false,message:e.message};}
}

function deleteSensei(token,id){
  try{const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);updateRowById(CONFIG.SHEETS.SENSEI,id,'SENSEI_ID',{STATUS:'NONAKTIF',UPDATED_AT:now()});logAction(user,'DEACTIVATE','SENSEI',id,'Sensei dinonaktifkan');return {success:true,message:'Sensei dinonaktifkan.'};}
  catch(e){return {success:false,message:e.message};}
}
