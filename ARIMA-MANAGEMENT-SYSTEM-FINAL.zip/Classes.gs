/**
 * Classes and schedules.
 */
function getClasses(token, filters){
  try{
    const user=requireAuth(token); let data=getAllRecords(CONFIG.SHEETS.CLASSES); filters=filters||{};
    if(user.ROLE===CONFIG.ROLES.SENSEI)data=data.filter(x=>x.SENSEI_ID===user.USER_ID);
    if(user.ROLE===CONFIG.ROLES.SISWA){const s=findById(CONFIG.SHEETS.STUDENTS,user.USER_ID,'STUDENT_ID');data=s?data.filter(x=>x.CLASS_ID===s.data.KELAS):[];}
    if(filters.status)data=data.filter(x=>x.STATUS===filters.status);
    if(filters.search){const q=String(filters.search).toLowerCase();data=data.filter(x=>[x.CLASS_ID,x.CLASS_NAME,x.PROGRAM,x.LEVEL].join(' ').toLowerCase().includes(q));}
    return {success:true,data};
  }catch(e){return {success:false,message:e.message};}
}

function saveClass(token,payload){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]); requireFields(payload,['CLASS_NAME','PROGRAM']);
    const id=sanitizeText(payload.CLASS_ID).toUpperCase()||generateId('CL',CONFIG.SHEETS.CLASSES,'CLASS_ID');
    const existing=findById(CONFIG.SHEETS.CLASSES,id,'CLASS_ID');
    const data={...payload,CLASS_ID:id,STATUS:payload.STATUS||'AKTIF',UPDATED_AT:now()};
    if(existing)updateRowById(CONFIG.SHEETS.CLASSES,id,'CLASS_ID',data);else{data.CREATED_AT=now();appendRowObject(CONFIG.SHEETS.CLASSES,data);}
    logAction(user,existing?'UPDATE':'CREATE','CLASSES',id,'Kelas disimpan');
    return {success:true,message:'Kelas berhasil disimpan.'};
  }catch(e){return {success:false,message:e.message};}
}

function getSchedules(token){
  try{
    const user=requireAuth(token); let data=getAllRecords(CONFIG.SHEETS.SCHEDULE);
    if(user.ROLE===CONFIG.ROLES.SENSEI)data=data.filter(x=>x.SENSEI_ID===user.USER_ID);
    if(user.ROLE===CONFIG.ROLES.SISWA){const s=findById(CONFIG.SHEETS.STUDENTS,user.USER_ID,'STUDENT_ID');data=s?data.filter(x=>x.CLASS_ID===s.data.KELAS):[];}
    return {success:true,data};
  }catch(e){return {success:false,message:e.message};}
}

function saveSchedule(token,payload){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]); requireFields(payload,['CLASS_ID','DAY','START_TIME','END_TIME']);
    const cls=findById(CONFIG.SHEETS.CLASSES,payload.CLASS_ID,'CLASS_ID');
    if(!cls)throw new Error('Kelas tidak ditemukan.');
    const sensei=payload.SENSEI_ID?findById(CONFIG.SHEETS.SENSEI,payload.SENSEI_ID,'SENSEI_ID'):null;
    const id=sanitizeText(payload.SCHEDULE_ID)||generateId('SC',CONFIG.SHEETS.SCHEDULE,'SCHEDULE_ID');
    const data={...payload,SCHEDULE_ID:id,CLASS_NAME:cls.data.CLASS_NAME,PROGRAM:cls.data.PROGRAM,SENSEI_NAME:sensei?sensei.data.NAMA:'',ROOM:payload.ROOM||cls.data.ROOM||'',STATUS:payload.STATUS||'AKTIF',UPDATED_AT:now()};
    const existing=findById(CONFIG.SHEETS.SCHEDULE,id,'SCHEDULE_ID');
    if(existing)updateRowById(CONFIG.SHEETS.SCHEDULE,id,'SCHEDULE_ID',data);else{data.CREATED_AT=now();appendRowObject(CONFIG.SHEETS.SCHEDULE,data);}
    logAction(user,existing?'UPDATE':'CREATE','SCHEDULE',id,'Jadwal disimpan');
    return {success:true,message:'Jadwal berhasil disimpan.'};
  }catch(e){return {success:false,message:e.message};}
}
