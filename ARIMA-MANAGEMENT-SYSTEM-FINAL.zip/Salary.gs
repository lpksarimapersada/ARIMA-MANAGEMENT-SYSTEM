/**
 * Sensei payroll.
 */
function getSalary(token,filters){
  try{
    const user=requireAuth(token);let data=getAllRecords(CONFIG.SHEETS.SALARY);filters=filters||{};
    if(user.ROLE===CONFIG.ROLES.SENSEI)data=data.filter(x=>x.SENSEI_ID===user.USER_ID);
    if(filters.period)data=data.filter(x=>x.PERIOD===filters.period);
    if(filters.senseiId)data=data.filter(x=>x.SENSEI_ID===filters.senseiId);
    return {success:true,data};
  }catch(e){return {success:false,message:e.message};}
}

function calculateSalary(token,payload){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);
    requireFields(payload,['PERIOD','SENSEI_ID']);
    const sensei=findById(CONFIG.SHEETS.SENSEI,payload.SENSEI_ID,'SENSEI_ID');if(!sensei)throw new Error('Sensei tidak ditemukan.');
    const period=payload.PERIOD;
    const details=getAllRecords(CONFIG.SHEETS.ATTENDANCE_SENSEI).filter(x=>x.SENSEI_ID===payload.SENSEI_ID&&String(x.DATE).slice(0,7)===period&&x.STATUS==='HADIR');
    const totalMeeting=details.length;
    const totalHours=sum(details,'TOTAL_HOURS');
    const method=payload.METHOD||'JAM';
    let base=method==='PERTEMUAN'?totalMeeting*cleanNumber(sensei.data.TARIF_PER_PERTEMUAN):method==='MANUAL'?cleanNumber(payload.BASE_SALARY):totalHours*cleanNumber(sensei.data.TARIF_PER_JAM);
    const bonus=cleanNumber(payload.BONUS),allowance=cleanNumber(payload.ALLOWANCE),deduction=cleanNumber(payload.DEDUCTION),net=base+bonus+allowance-deduction;
    const existing=getAllRecords(CONFIG.SHEETS.SALARY).find(x=>x.PERIOD===period&&x.SENSEI_ID===payload.SENSEI_ID);
    const id=existing?existing.SALARY_ID:generateId('SL',CONFIG.SHEETS.SALARY,'SALARY_ID');
    const row={SALARY_ID:id,PERIOD:period,SENSEI_ID:payload.SENSEI_ID,SENSEI_NAME:sensei.data.NAMA,TOTAL_MEETING:totalMeeting,TOTAL_HOURS:totalHours,BASE_SALARY:base,BONUS:bonus,ALLOWANCE:allowance,DEDUCTION:deduction,NET_SALARY:net,PAYMENT_DATE:existing?existing.PAYMENT_DATE:'',PAYMENT_STATUS:existing?existing.PAYMENT_STATUS:'BELUM DIBAYAR',NOTE:payload.NOTE||'',UPDATED_AT:now()};
    if(existing)updateRowById(CONFIG.SHEETS.SALARY,id,'SALARY_ID',row);else{row.CREATED_AT=now();appendRowObject(CONFIG.SHEETS.SALARY,row);}
    getAllRecords(CONFIG.SHEETS.SALARY_DETAIL).filter(x=>x.SALARY_ID===id).forEach(x=>deleteById(CONFIG.SHEETS.SALARY_DETAIL,x.DETAIL_ID,'DETAIL_ID'));
    details.forEach(d=>appendRowObject(CONFIG.SHEETS.SALARY_DETAIL,{DETAIL_ID:generateId('SD',CONFIG.SHEETS.SALARY_DETAIL,'DETAIL_ID'),SALARY_ID:id,DATE:d.DATE,CLASS_ID:d.CLASS_ID,CLASS_NAME:(getAllRecords(CONFIG.SHEETS.CLASSES).find(c=>c.CLASS_ID===d.CLASS_ID)||{}).CLASS_NAME||'',START_TIME:d.CHECK_IN,END_TIME:d.CHECK_OUT,TOTAL_HOURS:cleanNumber(d.TOTAL_HOURS),RATE:cleanNumber(sensei.data.TARIF_PER_JAM),AMOUNT:method==='PERTEMUAN'?cleanNumber(sensei.data.TARIF_PER_PERTEMUAN):cleanNumber(d.TOTAL_HOURS)*cleanNumber(sensei.data.TARIF_PER_JAM),NOTE:''}));
    logAction(user,existing?'UPDATE':'CREATE','SALARY',id,'Payroll dihitung untuk '+period);
    return {success:true,message:'Payroll berhasil dihitung.',data:row};
  }catch(e){return {success:false,message:e.message};}
}

function markSalaryPaid(token,salaryId,paymentDate){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);
    updateRowById(CONFIG.SHEETS.SALARY,salaryId,'SALARY_ID',{PAYMENT_STATUS:'SUDAH DIBAYAR',PAYMENT_DATE:parseDateInput(paymentDate)||todayISO(),UPDATED_AT:now()});
    logAction(user,'PAY','SALARY',salaryId,'Payroll ditandai sudah dibayar');
    return {success:true,message:'Payroll ditandai sudah dibayar.'};
  }catch(e){return {success:false,message:e.message};}
}

function getSalaryDetail(token,salaryId){
  try{
    const user=requireAuth(token);const s=findById(CONFIG.SHEETS.SALARY,salaryId,'SALARY_ID');if(!s)throw new Error('Payroll tidak ditemukan.');
    if(user.ROLE===CONFIG.ROLES.SENSEI&&s.data.SENSEI_ID!==user.USER_ID)throw new Error('Akses ditolak.');
    return {success:true,data:{salary:s.data,details:getAllRecords(CONFIG.SHEETS.SALARY_DETAIL).filter(x=>x.SALARY_ID===salaryId)}};
  }catch(e){return {success:false,message:e.message};}
}
