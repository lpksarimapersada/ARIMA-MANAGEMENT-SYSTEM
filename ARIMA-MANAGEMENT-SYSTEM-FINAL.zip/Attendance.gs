/**
 * Attendance for students and Sensei.
 */
function getStudentForAttendance(token,studentId){
  try{
    requireAuth(token,[CONFIG.ROLES.ADMIN,CONFIG.ROLES.SENSEI,CONFIG.ROLES.SISWA]);
    const rec=findById(CONFIG.SHEETS.STUDENTS,String(studentId).toUpperCase(),'STUDENT_ID');
    return {success:true,data:rec?rec.data:null};
  }catch(e){return {success:false,message:e.message};}
}

function recordStudentAttendance(token,payload){
  try{
    const user=requireAuth(token);
    const id=sanitizeText(payload.STUDENT_ID).toUpperCase();
    if(user.ROLE===CONFIG.ROLES.SISWA&&user.USER_ID!==id)throw new Error('Anda hanya dapat melakukan absensi untuk akun sendiri.');
    const student=findById(CONFIG.SHEETS.STUDENTS,id,'STUDENT_ID');
    if(!student)throw new Error('ID siswa tidak ditemukan.');
    const date=parseDateInput(payload.DATE)||todayISO();
    const sessionKey=sanitizeText(payload.SESSION_KEY)||'DEFAULT';
    const existing=getAllRecords(CONFIG.SHEETS.ATTENDANCE).find(x=>x.STUDENT_ID===id&&x.DATE===date&&x.SESSION_KEY===sessionKey);
    if(existing)return {success:false,duplicate:true,message:'Siswa sudah melakukan absensi pada sesi ini.',data:existing};
    const row={
      ATTENDANCE_ID:generateId('AT',CONFIG.SHEETS.ATTENDANCE,'ATTENDANCE_ID'),
      DATE:date,TIME:Utilities.formatDate(new Date(),CONFIG.TIMEZONE,'HH:mm:ss'),
      STUDENT_ID:id,STUDENT_NAME:student.data.NAMA,CLASS_ID:student.data.KELAS||'',
      STATUS:payload.STATUS||'HADIR',CHECK_IN:payload.CHECK_IN||Utilities.formatDate(new Date(),CONFIG.TIMEZONE,'HH:mm:ss'),
      CHECK_OUT:payload.CHECK_OUT||'',NOTE:payload.NOTE||'',RECORDED_BY:user.USER_ID,SESSION_KEY:sessionKey,CREATED_AT:now(),UPDATED_AT:now()
    };
    appendRowObject(CONFIG.SHEETS.ATTENDANCE,row);logAction(user,'CREATE','ATTENDANCE',row.ATTENDANCE_ID,'Absensi siswa');
    return {success:true,message:'Absensi berhasil dicatat.',data:row};
  }catch(e){return {success:false,message:e.message};}
}

function getStudentAttendance(token,studentId,filters){
  try{
    const user=requireAuth(token);
    if(user.ROLE===CONFIG.ROLES.SISWA)studentId=user.USER_ID;
    let data=getAllRecords(CONFIG.SHEETS.ATTENDANCE).filter(x=>x.STUDENT_ID===studentId);
    filters=filters||{};
    if(filters.from)data=data.filter(x=>x.DATE>=filters.from);
    if(filters.to)data=data.filter(x=>x.DATE<=filters.to);
    return {success:true,data};
  }catch(e){return {success:false,message:e.message};}
}

function getAllAttendance(token,filters){
  try{
    requireAuth(token,[CONFIG.ROLES.ADMIN,CONFIG.ROLES.SENSEI]);
    let data=getAllRecords(CONFIG.SHEETS.ATTENDANCE);filters=filters||{};
    if(filters.date)data=data.filter(x=>x.DATE===filters.date);
    if(filters.classId)data=data.filter(x=>x.CLASS_ID===filters.classId);
    if(filters.status)data=data.filter(x=>x.STATUS===filters.status);
    if(filters.search){const q=String(filters.search).toLowerCase();data=data.filter(x=>[x.STUDENT_ID,x.STUDENT_NAME].join(' ').toLowerCase().includes(q));}
    return {success:true,data};
  }catch(e){return {success:false,message:e.message};}
}

function updateStudentAttendance(token,id,payload){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);
    const data={STATUS:payload.STATUS,NOTE:payload.NOTE||'',CHECK_IN:payload.CHECK_IN||'',CHECK_OUT:payload.CHECK_OUT||'',UPDATED_AT:now()};
    updateRowById(CONFIG.SHEETS.ATTENDANCE,id,'ATTENDANCE_ID',data);
    logAction(user,'UPDATE','ATTENDANCE',id,'Absensi siswa dikoreksi: '+(payload.REASON||''));
    return {success:true,message:'Absensi berhasil diperbarui.'};
  }catch(e){return {success:false,message:e.message};}
}

function recordSenseiAttendance(token,payload){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN,CONFIG.ROLES.SENSEI]);
    const id=user.ROLE===CONFIG.ROLES.SENSEI?user.USER_ID:sanitizeText(payload.SENSEI_ID).toUpperCase();
    const sensei=findById(CONFIG.SHEETS.SENSEI,id,'SENSEI_ID'); if(!sensei)throw new Error('Sensei tidak ditemukan.');
    const date=parseDateInput(payload.DATE)||todayISO(), sessionKey=sanitizeText(payload.SESSION_KEY)||'DEFAULT';
    const existing=getAllRecords(CONFIG.SHEETS.ATTENDANCE_SENSEI).find(x=>x.SENSEI_ID===id&&x.DATE===date&&x.SESSION_KEY===sessionKey);
    if(existing)return {success:false,duplicate:true,message:'Absensi Sensei sudah ada untuk sesi ini.',data:existing};
    const checkIn=payload.CHECK_IN||Utilities.formatDate(new Date(),CONFIG.TIMEZONE,'HH:mm:ss');
    const row={ATTENDANCE_SENSEI_ID:generateId('AS',CONFIG.SHEETS.ATTENDANCE_SENSEI,'ATTENDANCE_SENSEI_ID'),DATE:date,TIME:Utilities.formatDate(new Date(),CONFIG.TIMEZONE,'HH:mm:ss'),SENSEI_ID:id,SENSEI_NAME:sensei.data.NAMA,CLASS_ID:payload.CLASS_ID||'',CHECK_IN:checkIn,CHECK_OUT:payload.CHECK_OUT||'',TOTAL_HOURS:cleanNumber(payload.TOTAL_HOURS),STATUS:payload.STATUS||'HADIR',NOTE:payload.NOTE||'',RECORDED_BY:user.USER_ID,SESSION_KEY:sessionKey,CREATED_AT:now(),UPDATED_AT:now()};
    appendRowObject(CONFIG.SHEETS.ATTENDANCE_SENSEI,row);logAction(user,'CREATE','ATTENDANCE_SENSEI',row.ATTENDANCE_SENSEI_ID,'Absensi Sensei');
    return {success:true,message:'Absensi Sensei berhasil dicatat.',data:row};
  }catch(e){return {success:false,message:e.message};}
}

function getSenseiAttendance(token,senseiId,filters){
  try{
    const user=requireAuth(token);
    if(user.ROLE===CONFIG.ROLES.SENSEI)senseiId=user.USER_ID;
    let data=getAllRecords(CONFIG.SHEETS.ATTENDANCE_SENSEI).filter(x=>x.SENSEI_ID===senseiId);
    filters=filters||{};if(filters.from)data=data.filter(x=>x.DATE>=filters.from);if(filters.to)data=data.filter(x=>x.DATE<=filters.to);
    return {success:true,data};
  }catch(e){return {success:false,message:e.message};}
}
