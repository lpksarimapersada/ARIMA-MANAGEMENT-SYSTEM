/**
 * Student payments and receipts.
 */
function getPayments(token,filters){
  try{
    const user=requireAuth(token);let data=getAllRecords(CONFIG.SHEETS.PAYMENTS);filters=filters||{};
    if(user.ROLE===CONFIG.ROLES.SISWA)data=data.filter(x=>x.STUDENT_ID===user.USER_ID);
    if(filters.billId)data=data.filter(x=>x.BILL_ID===filters.billId);
    if(filters.studentId)data=data.filter(x=>x.STUDENT_ID===filters.studentId);
    if(filters.search){const q=String(filters.search).toLowerCase();data=data.filter(x=>[x.PAYMENT_ID,x.BILL_ID,x.STUDENT_ID,x.RECEIPT_NO].join(' ').toLowerCase().includes(q));}
    return {success:true,data};
  }catch(e){return {success:false,message:e.message};}
}

function recordPayment(token,payload){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);requireFields(payload,['BILL_ID','AMOUNT']);
    const bill=findById(CONFIG.SHEETS.BILLING,payload.BILL_ID,'BILL_ID');if(!bill)throw new Error('Tagihan tidak ditemukan.');
    const amount=cleanNumber(payload.AMOUNT);if(amount<=0)throw new Error('Nominal pembayaran harus lebih dari 0.');
    recalcBill_(payload.BILL_ID);
    const latest=findById(CONFIG.SHEETS.BILLING,payload.BILL_ID,'BILL_ID').data;
    if(amount>cleanNumber(latest.REMAINING))throw new Error('Pembayaran melebihi sisa tagihan.');
    const id=generateId('PY',CONFIG.SHEETS.PAYMENTS,'PAYMENT_ID');
    const receiptPrefix=getSetting('RECEIPT_PREFIX')||CONFIG.RECEIPT_PREFIX;
    const receiptNo=receiptPrefix+'-'+Utilities.formatDate(new Date(),CONFIG.TIMEZONE,'yyyyMM')+'-'+String(getAllRecords(CONFIG.SHEETS.PAYMENTS).length+1).padStart(4,'0');
    const row={PAYMENT_ID:id,BILL_ID:payload.BILL_ID,STUDENT_ID:latest.STUDENT_ID,PAYMENT_DATE:parseDateInput(payload.PAYMENT_DATE)||todayISO(),AMOUNT:amount,PAYMENT_METHOD:payload.PAYMENT_METHOD||'CASH',REFERENCE:payload.REFERENCE||'',RECEIVED_BY:user.NAME,NOTE:payload.NOTE||'',RECEIPT_NO:receiptNo,CREATED_AT:now()};
    appendRowObject(CONFIG.SHEETS.PAYMENTS,row);recalcBill_(payload.BILL_ID);
    logAction(user,'CREATE','PAYMENTS',id,'Pembayaran dicatat');
    return {success:true,message:'Pembayaran berhasil dicatat.',data:row};
  }catch(e){return {success:false,message:e.message};}
}

function getReceipt(token,paymentId){
  try{
    const user=requireAuth(token);const p=findById(CONFIG.SHEETS.PAYMENTS,paymentId,'PAYMENT_ID');if(!p)throw new Error('Pembayaran tidak ditemukan.');
    if(user.ROLE===CONFIG.ROLES.SISWA&&p.data.STUDENT_ID!==user.USER_ID)throw new Error('Akses ditolak.');
    const b=findById(CONFIG.SHEETS.BILLING,p.data.BILL_ID,'BILL_ID');
    const s=findById(CONFIG.SHEETS.STUDENTS,p.data.STUDENT_ID,'STUDENT_ID');
    return {success:true,data:{payment:p.data,bill:b?b.data:null,student:s?s.data:null,company:getAppInfo()}};
  }catch(e){return {success:false,message:e.message};}
}
