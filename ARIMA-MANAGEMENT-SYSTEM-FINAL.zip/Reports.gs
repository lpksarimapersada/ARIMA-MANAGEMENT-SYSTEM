/**
 * Dashboard and reporting.
 */
function getDashboard(token){
  try{
    const user=requireAuth(token);
    const students=getAllRecords(CONFIG.SHEETS.STUDENTS);
    const sensei=getAllRecords(CONFIG.SHEETS.SENSEI);
    const attendance=getAllRecords(CONFIG.SHEETS.ATTENDANCE);
    const billing=getAllRecords(CONFIG.SHEETS.BILLING);
    const payments=getAllRecords(CONFIG.SHEETS.PAYMENTS);
    const salary=getAllRecords(CONFIG.SHEETS.SALARY);
    const today=todayISO(), month=today.slice(0,7);
    let myStudent=null,mySensei=null;
    if(user.ROLE===CONFIG.ROLES.SISWA)myStudent=students.find(x=>x.STUDENT_ID===user.USER_ID);
    if(user.ROLE===CONFIG.ROLES.SENSEI)mySensei=sensei.find(x=>x.SENSEI_ID===user.USER_ID);
    const myAtt=myStudent?attendance.filter(x=>x.STUDENT_ID===user.USER_ID&&String(x.DATE).slice(0,7)===month):[];
    const mySal=mySensei?salary.filter(x=>x.SENSEI_ID===user.USER_ID&&x.PERIOD===month):[];
    return {success:true,data:{
      user:safeUser(user),today,
      admin:{
        students:students.length,activeStudents:students.filter(x=>x.STATUS==='AKTIF').length,
        magang:students.filter(x=>x.PROGRAM==='MAGANG').length,ssw:students.filter(x=>x.PROGRAM==='SSW / TOKUTEI GINOU').length,
        engineering:students.filter(x=>x.PROGRAM==='ENGINEERING'||x.PROGRAM==='ENGINEER').length,
        sensei:sensei.length,activeSensei:sensei.filter(x=>x.STATUS==='AKTIF').length,
        attendanceToday:attendance.filter(x=>x.DATE===today).reduce((o,x)=>{o[x.STATUS]=(o[x.STATUS]||0)+1;return o;},{}),
        billingTotal:sum(billing,'TOTAL'),paidTotal:sum(billing,'PAID'),remaining:sum(billing,'REMAINING'),
        overdue:billing.filter(x=>x.STATUS==='JATUH TEMPO').length,
        salaryMonth:sum(salary.filter(x=>x.PERIOD===month),'NET_SALARY'),
        salaryPaid:sum(salary.filter(x=>x.PERIOD===month&&x.PAYMENT_STATUS==='SUDAH DIBAYAR'),'NET_SALARY'),
        salaryUnpaid:sum(salary.filter(x=>x.PERIOD===month&&x.PAYMENT_STATUS!=='SUDAH DIBAYAR'),'NET_SALARY')
      },
      student:{
        profile:myStudent,attendance:myAtt,
        present:myAtt.filter(x=>x.STATUS==='HADIR').length,izin:myAtt.filter(x=>x.STATUS==='IZIN').length,
        sick:myAtt.filter(x=>x.STATUS==='SAKIT').length,absent:myAtt.filter(x=>x.STATUS==='ALPA').length,
        billing:billing.filter(x=>x.STUDENT_ID===user.USER_ID),payments:payments.filter(x=>x.STUDENT_ID===user.USER_ID)
      },
      sensei:{
        profile:mySensei,attendance:getAllRecords(CONFIG.SHEETS.ATTENDANCE_SENSEI).filter(x=>x.SENSEI_ID===user.USER_ID&&String(x.DATE).slice(0,7)===month),
        salary:mySal
      }
    }};
  }catch(e){return {success:false,message:e.message};}
}

function getLogs(token,filters){
  try{
    requireAuth(token,[CONFIG.ROLES.ADMIN]);let data=getAllRecords(CONFIG.SHEETS.LOGS);filters=filters||{};
    if(filters.search){const q=String(filters.search).toLowerCase();data=data.filter(x=>JSON.stringify(x).toLowerCase().includes(q));}
    return {success:true,data:data.slice(-500).reverse()};
  }catch(e){return {success:false,message:e.message};}
}
