/**
 * Admin utilities.
 */
function getAdminBootstrap(token){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);
    return {success:true,data:{
      app:getAppInfo(),
      students:getAllRecords(CONFIG.SHEETS.STUDENTS),
      sensei:getAllRecords(CONFIG.SHEETS.SENSEI),
      classes:getAllRecords(CONFIG.SHEETS.CLASSES),
      schedules:getAllRecords(CONFIG.SHEETS.SCHEDULE),
      billing:getAllRecords(CONFIG.SHEETS.BILLING),
      payments:getAllRecords(CONFIG.SHEETS.PAYMENTS)
    }};
  }catch(e){return {success:false,message:e.message};}
}
