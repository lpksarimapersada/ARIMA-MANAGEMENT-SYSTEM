/**
 * Authentication and authorization.
 */
function createAdmin(payload) {
  try {
    setupDatabase();
    requireFields(payload,['userId','password','name']);
    const userId = sanitizeText(payload.userId).toUpperCase();
    const password = String(payload.password);
    if (password.length < 8) throw new Error('Password minimal 8 karakter.');
    if (findById(CONFIG.SHEETS.USERS,userId,'USER_ID')) throw new Error('Admin ID sudah digunakan.');
    const salt = createSalt();
    const user = {
      USER_ID:userId, USERNAME:userId, PASSWORD_HASH:hashPassword(password,salt),
      PASSWORD_SALT:salt, ROLE:CONFIG.ROLES.ADMIN, NAME:sanitizeText(payload.name),
      EMAIL:sanitizeText(payload.email), PHONE:sanitizeText(payload.phone),
      STATUS:'AKTIF', LAST_LOGIN:'', CREATED_AT:now(), UPDATED_AT:now()
    };
    appendRowObject(CONFIG.SHEETS.USERS,user);
    return {success:true,message:'Admin berhasil dibuat. Simpan ID dan password dengan aman.',userId};
  } catch(e) {
    return {success:false,message:e.message};
  }
}

function login(userId,password) {
  try {
    const id = sanitizeText(userId).toUpperCase();
    const rec = findById(CONFIG.SHEETS.USERS,id,'USER_ID');
    if (!rec) throw new Error('ID atau password salah.');
    const u = rec.data;
    if (u.STATUS !== 'AKTIF') throw new Error('Akun tidak aktif.');
    if (hashPassword(password,u.PASSWORD_SALT) !== u.PASSWORD_HASH) throw new Error('ID atau password salah.');
    const token = randomToken();
    const session = {
      USER_ID:u.USER_ID, USERNAME:u.USERNAME, ROLE:u.ROLE, NAME:u.NAME,
      EMAIL:u.EMAIL, PHONE:u.PHONE, CREATED_AT:now()
    };
    CacheService.getScriptCache().put('SESSION_' + token, JSON.stringify(session), CONFIG.SESSION_TTL);
    updateRowById(CONFIG.SHEETS.USERS,id,'USER_ID',{LAST_LOGIN:now(),UPDATED_AT:now()});
    logAction(session,'LOGIN','AUTH',id,'User login');
    return {success:true,token,user:safeUser(session)};
  } catch(e) {
    return {success:false,message:e.message};
  }
}

function safeUser(user) {
  if (!user) return null;
  return {USER_ID:user.USER_ID,USERNAME:user.USERNAME,ROLE:user.ROLE,NAME:user.NAME,EMAIL:user.EMAIL,PHONE:user.PHONE};
}

function getSession(token) {
  if (!token) return null;
  const raw = CacheService.getScriptCache().get('SESSION_' + token);
  if (!raw) return null;
  return JSON.parse(raw);
}

function requireAuth(token, roles) {
  const user = getSession(token);
  if (!user) throw new Error('Sesi login telah berakhir. Silakan login kembali.');
  if (roles && roles.length && roles.indexOf(user.ROLE) === -1) throw new Error('Anda tidak memiliki akses ke fitur ini.');
  return user;
}

function logout(token) {
  try {
    const user = getSession(token);
    if (user) logAction(user,'LOGOUT','AUTH',user.USER_ID,'User logout');
    CacheService.getScriptCache().remove('SESSION_' + token);
    return {success:true};
  } catch(e) {
    return {success:false,message:e.message};
  }
}

function validateSession(token) {
  const user = getSession(token);
  return {valid:!!user,user:safeUser(user)};
}

function changePassword(token, oldPassword, newPassword) {
  try {
    const user = requireAuth(token);
    if (!newPassword || String(newPassword).length < 8) throw new Error('Password baru minimal 8 karakter.');
    const rec = findById(CONFIG.SHEETS.USERS,user.USER_ID,'USER_ID');
    if (!rec || hashPassword(oldPassword,rec.data.PASSWORD_SALT) !== rec.data.PASSWORD_HASH) throw new Error('Password lama salah.');
    const salt = createSalt();
    updateRowById(CONFIG.SHEETS.USERS,user.USER_ID,'USER_ID',{
      PASSWORD_HASH:hashPassword(newPassword,salt),PASSWORD_SALT:salt,UPDATED_AT:now()
    });
    logAction(user,'CHANGE_PASSWORD','AUTH',user.USER_ID,'Password diubah');
    return {success:true,message:'Password berhasil diubah.'};
  } catch(e) { return {success:false,message:e.message}; }
}

function getUsers(token) {
  try {
    requireAuth(token,[CONFIG.ROLES.ADMIN]);
    return {success:true,data:getAllRecords(CONFIG.SHEETS.USERS).map(u=>{
      const x = {...u}; delete x.PASSWORD_HASH; delete x.PASSWORD_SALT; return x;
    })};
  } catch(e) { return {success:false,message:e.message}; }
}

function saveUser(token,payload) {
  try {
    const admin = requireAuth(token,[CONFIG.ROLES.ADMIN]);
    requireFields(payload,['USER_ID','NAME','ROLE']);
    const id = sanitizeText(payload.USER_ID).toUpperCase();
    const existing = findById(CONFIG.SHEETS.USERS,id,'USER_ID');
    const data = {
      USER_ID:id, USERNAME:payload.USERNAME || id, ROLE:payload.ROLE, NAME:payload.NAME,
      EMAIL:payload.EMAIL || '', PHONE:payload.PHONE || '', STATUS:payload.STATUS || 'AKTIF',
      UPDATED_AT:now()
    };
    if (existing) {
      if (payload.PASSWORD) {
        const salt = createSalt(); data.PASSWORD_HASH=hashPassword(payload.PASSWORD,salt); data.PASSWORD_SALT=salt;
      }
      updateRowById(CONFIG.SHEETS.USERS,id,'USER_ID',data);
      logAction(admin,'UPDATE','USERS',id,'User diperbarui');
    } else {
      const salt=createSalt();
      data.PASSWORD_HASH=hashPassword(payload.PASSWORD || 'ChangeMe123!',salt);
      data.PASSWORD_SALT=salt; data.LAST_LOGIN=''; data.CREATED_AT=now();
      appendRowObject(CONFIG.SHEETS.USERS,data);
      logAction(admin,'CREATE','USERS',id,'User dibuat');
    }
    return {success:true,message:'User berhasil disimpan.'};
  } catch(e) { return {success:false,message:e.message}; }
}
