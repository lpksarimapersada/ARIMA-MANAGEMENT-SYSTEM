/**
 * Database layer. Spreadsheet is the single source of truth.
 */
function getSpreadsheet() {
  return SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
}

function getSheet(name) {
  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(name);
  if (!sheet) throw new Error('Sheet tidak ditemukan: ' + name);
  return sheet;
}

function getHeaders(sheet) {
  const lastCol = sheet.getLastColumn();
  return lastCol ? sheet.getRange(1,1,1,lastCol).getValues()[0].map(String) : [];
}

function ensureSheet(name, headers) {
  const ss = getSpreadsheet();
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  const current = getHeaders(sheet);
  if (!current.length) {
    sheet.getRange(1,1,1,headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    sheet.getRange(1,1,1,headers.length).setFontWeight('bold');
  } else if (current.join('|') !== headers.join('|')) {
    // Never overwrite existing data. Only add missing headers to the right.
    const missing = headers.filter(h => current.indexOf(h) === -1);
    if (missing.length) sheet.getRange(1,current.length+1,1,missing.length).setValues([missing]);
  }
  return sheet;
}

function rowToObject(headers, row) {
  const obj = {};
  headers.forEach((h,i) => obj[h] = row[i] instanceof Date ? formatDateTime(row[i]) : row[i]);
  return obj;
}

function getAllRecords(sheetName) {
  const sheet = getSheet(sheetName);
  const values = sheet.getDataRange().getValues();
  if (values.length <= 1) return [];
  const headers = values[0].map(String);
  return values.slice(1).filter(r => r.some(v => v !== '')).map(r => rowToObject(headers,r));
}

function findById(sheetName, id, idField) {
  const sheet = getSheet(sheetName);
  const values = sheet.getDataRange().getValues();
  if (values.length <= 1) return null;
  const headers = values[0].map(String);
  const idx = headers.indexOf(idField);
  if (idx < 0) throw new Error('Field ID tidak ditemukan: ' + idField);
  for (let i=1;i<values.length;i++) {
    if (String(values[i][idx]) === String(id)) return {rowIndex:i+1, data:rowToObject(headers,values[i])};
  }
  return null;
}

function appendRowObject(sheetName, data) {
  const sheet = getSheet(sheetName);
  const headers = getHeaders(sheet);
  const row = headers.map(h => data[h] !== undefined ? data[h] : '');
  sheet.appendRow(row);
  return rowToObject(headers,row);
}

function updateRowById(sheetName, id, idField, data) {
  const found = findById(sheetName,id,idField);
  if (!found) throw new Error('Data tidak ditemukan: ' + id);
  const sheet = getSheet(sheetName);
  const headers = getHeaders(sheet);
  const current = sheet.getRange(found.rowIndex,1,1,headers.length).getValues()[0];
  const row = headers.map((h,i) => data[h] !== undefined ? data[h] : current[i]);
  sheet.getRange(found.rowIndex,1,1,headers.length).setValues([row]);
  return rowToObject(headers,row);
}

function deleteById(sheetName, id, idField) {
  const found = findById(sheetName,id,idField);
  if (!found) throw new Error('Data tidak ditemukan: ' + id);
  getSheet(sheetName).deleteRow(found.rowIndex);
  return true;
}

function generateId(prefix, sheetName, idField) {
  const records = getAllRecords(sheetName);
  let max = 0;
  const re = new RegExp('^' + prefix.replace(/[.*+?^${}()|[\]\\]/g,'\\$&') + '(\\d+)$');
  records.forEach(r => {
    const m = String(r[idField] || '').match(re);
    if (m) max = Math.max(max, Number(m[1]));
  });
  return prefix + String(max+1).padStart(3,'0');
}

function setupDatabase() {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    Object.keys(CONFIG.SHEETS).forEach(k => ensureSheet(CONFIG.SHEETS[k], HEADERS[k]));
    seedDefaultSettings();
    SpreadsheetApp.flush();
    return {success:true, message:'DATABASE READY — semua sheet dan header telah disiapkan.'};
  } catch (e) {
    console.error(e);
    return {success:false, message:e.message};
  } finally {
    lock.releaseLock();
  }
}

function seedDefaultSettings() {
  const defaults = {
    COMPANY_NAME: CONFIG.COMPANY_NAME,
    APP_NAME: CONFIG.APP_NAME,
    TAGLINE: CONFIG.TAGLINE,
    PHONE: '',
    EMAIL: '',
    WEBSITE: 'https://arimapersada.vercel.app',
    LOGO_DATA: getEmbeddedLogoData_(),
    RECEIPT_PREFIX: CONFIG.RECEIPT_PREFIX,
    ATTENDANCE_DUPLICATE_POLICY: 'ONE_PER_STUDENT_PER_SESSION'
  };
  const existing = {};
  getAllRecords(CONFIG.SHEETS.SETTINGS).forEach(r => existing[r.KEY] = true);
  Object.keys(defaults).forEach(k => {
    if (!existing[k]) appendRowObject(CONFIG.SHEETS.SETTINGS, {
      KEY:k, VALUE:defaults[k], DESCRIPTION:'Default setting', UPDATED_AT:now()
    });
  });
}

function seedDemoData() {
  setupDatabase();
  try {
    const students = getAllRecords(CONFIG.SHEETS.STUDENTS);
    if (!students.length) {
      const classId = generateId('CL',CONFIG.SHEETS.CLASSES,'CLASS_ID');
      const senseiId = generateId(CONFIG.SENSEI_PREFIX,CONFIG.SHEETS.SENSEI,'SENSEI_ID');
      const studentRows = [
        {STUDENT_ID:'SW001',NIK:'3170000000000001',NAMA:'Raka Pratama',NAMA_PANGGILAN:'Raka',PROGRAM:'SSW / TOKUTEI GINOU',KELAS:classId,STATUS:'AKTIF',NO_WA:'081234567890',ASRAMA:'Tidak',CREATED_AT:now(),UPDATED_AT:now()},
        {STUDENT_ID:'SW002',NIK:'3170000000000002',NAMA:'Fajar Nugraha',NAMA_PANGGILAN:'Fajar',PROGRAM:'MAGANG',KELAS:classId,STATUS:'AKTIF',NO_WA:'081234567891',ASRAMA:'Ya',CREATED_AT:now(),UPDATED_AT:now()},
        {STUDENT_ID:'SW003',NIK:'3170000000000003',NAMA:'Dika Saputra',NAMA_PANGGILAN:'Dika',PROGRAM:'ENGINEERING',KELAS:classId,STATUS:'AKTIF',NO_WA:'081234567892',ASRAMA:'Tidak',CREATED_AT:now(),UPDATED_AT:now()}
      ];
      studentRows.forEach(r=>appendRowObject(CONFIG.SHEETS.STUDENTS,r));
      appendRowObject(CONFIG.SHEETS.SENSEI,{SENSEI_ID:senseiId,NAMA:'Rahmat Sensei',NAMA_PANGGILAN:'Rahmat',SPESIALISASI:'Bahasa Jepang',TARIF_PER_JAM:50000,TARIF_PER_PERTEMUAN:75000,STATUS:'AKTIF',CREATED_AT:now(),UPDATED_AT:now()});
      appendRowObject(CONFIG.SHEETS.CLASSES,{CLASS_ID:classId,CLASS_NAME:'SSW-A',PROGRAM:'SSW / TOKUTEI GINOU',LEVEL:'N4',SENSEI_ID:senseiId,ROOM:'R1',DAY:'SENIN',START_TIME:'08:00',END_TIME:'10:00',STATUS:'AKTIF',CREATED_AT:now(),UPDATED_AT:now()});
      appendRowObject(CONFIG.SHEETS.SCHEDULE,{SCHEDULE_ID:generateId('SC',CONFIG.SHEETS.SCHEDULE,'SCHEDULE_ID'),CLASS_ID:classId,CLASS_NAME:'SSW-A',PROGRAM:'SSW / TOKUTEI GINOU',SENSEI_ID:senseiId,SENSEI_NAME:'Rahmat Sensei',DAY:'SENIN',START_TIME:'08:00',END_TIME:'10:00',ROOM:'R1',STATUS:'AKTIF',CREATED_AT:now(),UPDATED_AT:now()});
    }
    return {success:true,message:'Demo data berhasil dibuat.'};
  } catch(e) {
    return {success:false,message:e.message};
  }
}
