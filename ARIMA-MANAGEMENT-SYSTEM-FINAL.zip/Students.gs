/**
 * Student management.
 */
function getStudents(token, filters) {
  try {
    const user = requireAuth(token);
    let data = getAllRecords(CONFIG.SHEETS.STUDENTS);
    if (user.ROLE === CONFIG.ROLES.SISWA) data = data.filter(x=>x.STUDENT_ID===user.USER_ID);
    filters = filters || {};
    if (filters.status) data=data.filter(x=>x.STATUS===filters.status);
    if (filters.program) data=data.filter(x=>x.PROGRAM===filters.program);
    if (filters.classId) data=data.filter(x=>x.KELAS===filters.classId);
    if (filters.search) {
      const q=String(filters.search).toLowerCase();
      data=data.filter(x=>[x.STUDENT_ID,x.NAMA,x.NIK,x.NO_WA].join(' ').toLowerCase().includes(q));
    }
    return {success:true,data};
  } catch(e){return {success:false,message:e.message};}
}

function getStudent(token,id) {
  try {
    const user=requireAuth(token);
    if (user.ROLE===CONFIG.ROLES.SISWA && user.USER_ID!==id) throw new Error('Akses ditolak.');
    const rec=findById(CONFIG.SHEETS.STUDENTS,id,'STUDENT_ID');
    return {success:true,data:rec ? rec.data : null};
  } catch(e){return {success:false,message:e.message};}
}

function saveStudent(token,payload) {
  try {
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);
    payload=payload||{};
    requireFields(payload,['NAMA','PROGRAM']);
    const id=sanitizeText(payload.STUDENT_ID).toUpperCase() || generateId(CONFIG.STUDENT_PREFIX,CONFIG.SHEETS.STUDENTS,'STUDENT_ID');
    const existing=findById(CONFIG.SHEETS.STUDENTS,id,'STUDENT_ID');
    const data={...payload,STUDENT_ID:id,TANGGAL_LAHIR:parseDateInput(payload.TANGGAL_LAHIR),TANGGAL_MASUK:parseDateInput(payload.TANGGAL_MASUK),STATUS:payload.STATUS||'AKTIF',UPDATED_AT:now()};
    if(existing){updateRowById(CONFIG.SHEETS.STUDENTS,id,'STUDENT_ID',data);logAction(user,'UPDATE','STUDENTS',id,'Data siswa diperbarui');}
    else {data.CREATED_AT=now();appendRowObject(CONFIG.SHEETS.STUDENTS,data);logAction(user,'CREATE','STUDENTS',id,'Siswa baru ditambahkan');}
    return {success:true,message:'Data siswa berhasil disimpan.',data:getStudent(token,id).data};
  }catch(e){return {success:false,message:e.message};}
}

function deleteStudent(token,id) {
  try {
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);
    updateRowById(CONFIG.SHEETS.STUDENTS,id,'STUDENT_ID',{STATUS:'NONAKTIF',UPDATED_AT:now()});
    logAction(user,'DEACTIVATE','STUDENTS',id,'Siswa dinonaktifkan');
    return {success:true,message:'Siswa dinonaktifkan.'};
  }catch(e){return {success:false,message:e.message};}
}
