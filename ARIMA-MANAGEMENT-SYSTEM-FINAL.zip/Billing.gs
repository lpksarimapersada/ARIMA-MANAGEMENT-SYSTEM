/**
 * Billing, activities and WhatsApp reminders.
 */
function getBilling(token,filters){
  try{
    const user=requireAuth(token);let data=getAllRecords(CONFIG.SHEETS.BILLING);filters=filters||{};
    if(user.ROLE===CONFIG.ROLES.SISWA)data=data.filter(x=>x.STUDENT_ID===user.USER_ID);
    if(filters.status)data=data.filter(x=>x.STATUS===filters.status);
    if(filters.studentId)data=data.filter(x=>x.STUDENT_ID===filters.studentId);
    if(filters.search){const q=String(filters.search).toLowerCase();data=data.filter(x=>[x.BILL_ID,x.STUDENT_ID,x.STUDENT_NAME,x.DESCRIPTION].join(' ').toLowerCase().includes(q));}
    return {success:true,data};
  }catch(e){return {success:false,message:e.message};}
}

function recalcBill_(billId){
  const bill=findById(CONFIG.SHEETS.BILLING,billId,'BILL_ID');if(!bill)throw new Error('Tagihan tidak ditemukan.');
  const payments=getAllRecords(CONFIG.SHEETS.PAYMENTS).filter(x=>x.BILL_ID===billId);
  const paid=sum(payments,'AMOUNT'), total=cleanNumber(bill.data.AMOUNT)-cleanNumber(bill.data.DISCOUNT), remaining=Math.max(0,total-paid);
  let status=remaining<=0?'LUNAS':paid>0?'SEBAGIAN':'BELUM BAYAR';
  const due=parseDateInput(bill.data.DUE_DATE);if(remaining>0&&due&&due<todayISO())status='JATUH TEMPO';
  return updateRowById(CONFIG.SHEETS.BILLING,billId,'BILL_ID',{TOTAL:total,PAID:paid,REMAINING:remaining,STATUS:status,UPDATED_AT:now()});
}

function saveBilling(token,payload){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);requireFields(payload,['STUDENT_ID','BILL_TYPE','DESCRIPTION','AMOUNT']);
    const student=findById(CONFIG.SHEETS.STUDENTS,payload.STUDENT_ID,'STUDENT_ID');if(!student)throw new Error('Siswa tidak ditemukan.');
    const id=sanitizeText(payload.BILL_ID)||generateId('BL',CONFIG.SHEETS.BILLING,'BILL_ID');
    const existing=findById(CONFIG.SHEETS.BILLING,id,'BILL_ID');
    const amount=cleanNumber(payload.AMOUNT),discount=cleanNumber(payload.DISCOUNT);
    const data={...payload,BILL_ID:id,STUDENT_NAME:student.data.NAMA,DUE_DATE:parseDateInput(payload.DUE_DATE),AMOUNT:amount,DISCOUNT:discount,TOTAL:Math.max(0,amount-discount),PAID:existing?existing.data.PAID:0,REMAINING:Math.max(0,amount-discount-(existing?cleanNumber(existing.data.PAID):0)),STATUS:existing?existing.data.STATUS:'BELUM BAYAR',UPDATED_AT:now()};
    if(existing)updateRowById(CONFIG.SHEETS.BILLING,id,'BILL_ID',data);else{data.CREATED_AT=now();appendRowObject(CONFIG.SHEETS.BILLING,data);}
    recalcBill_(id);logAction(user,existing?'UPDATE':'CREATE','BILLING',id,'Tagihan siswa disimpan');
    return {success:true,message:'Tagihan berhasil disimpan.'};
  }catch(e){return {success:false,message:e.message};}
}

function deleteBilling(token,id){
  try{const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);deleteById(CONFIG.SHEETS.BILLING,id,'BILL_ID');logAction(user,'DELETE','BILLING',id,'Tagihan dihapus');return {success:true,message:'Tagihan dihapus.'};}
  catch(e){return {success:false,message:e.message};}
}

function getActivities(token){
  try{requireAuth(token,[CONFIG.ROLES.ADMIN]);return {success:true,data:getAllRecords(CONFIG.SHEETS.ACTIVITIES)};}
  catch(e){return {success:false,message:e.message};}
}

function saveActivity(token,payload){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);requireFields(payload,['NAME','FEE']);
    const id=sanitizeText(payload.ACTIVITY_ID)||generateId('AC',CONFIG.SHEETS.ACTIVITIES,'ACTIVITY_ID');
    const existing=findById(CONFIG.SHEETS.ACTIVITIES,id,'ACTIVITY_ID');
    const data={...payload,ACTIVITY_ID:id,FEE:cleanNumber(payload.FEE),DUE_DATE:parseDateInput(payload.DUE_DATE),STATUS:payload.STATUS||'AKTIF',UPDATED_AT:now()};
    if(existing)updateRowById(CONFIG.SHEETS.ACTIVITIES,id,'ACTIVITY_ID',data);else{data.CREATED_AT=now();appendRowObject(CONFIG.SHEETS.ACTIVITIES,data);}
    logAction(user,existing?'UPDATE':'CREATE','ACTIVITIES',id,'Aktivitas disimpan');
    return {success:true,message:'Aktivitas berhasil disimpan.'};
  }catch(e){return {success:false,message:e.message};}
}

function makeBillingFromActivity(token,activityId,studentIds){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);const a=findById(CONFIG.SHEETS.ACTIVITIES,activityId,'ACTIVITY_ID');if(!a)throw new Error('Aktivitas tidak ditemukan.');
    let created=0; (studentIds||[]).forEach(sid=>{saveBilling(token,{STUDENT_ID:sid,BILL_TYPE:'KEGIATAN',DESCRIPTION:a.data.NAME,PERIOD:todayISO().slice(0,7),DUE_DATE:a.data.DUE_DATE,AMOUNT:a.data.FEE,DISCOUNT:0,NOTE:'Dibuat dari aktivitas '+activityId});created++;});
    logAction(user,'CREATE_BULK','BILLING',activityId,'Membuat '+created+' tagihan dari aktivitas');
    return {success:true,message:created+' tagihan berhasil dibuat.'};
  }catch(e){return {success:false,message:e.message};}
}

function getBillReminder(token,billId){
  try{
    const user=requireAuth(token,[CONFIG.ROLES.ADMIN]);const bill=findById(CONFIG.SHEETS.BILLING,billId,'BILL_ID');if(!bill)throw new Error('Tagihan tidak ditemukan.');
    const student=findById(CONFIG.SHEETS.STUDENTS,bill.data.STUDENT_ID,'STUDENT_ID');if(!student)throw new Error('Siswa tidak ditemukan.');
    const msg=`Halo ${student.data.NAMA}.\n\nKami dari LPKS Arima Persada menginformasikan bahwa terdapat tagihan:\n\nJenis: ${bill.data.BILL_TYPE}\nKeterangan: ${bill.data.DESCRIPTION}\nJumlah: ${formatRupiahServer(bill.data.TOTAL)}\nJatuh tempo: ${bill.data.DUE_DATE || '-'}\n\nSisa tagihan: ${formatRupiahServer(bill.data.REMAINING)}\n\nMohon dapat melakukan pembayaran sesuai ketentuan.\n\nTerima kasih.\n\nLPKS Arima Persada\n${CONFIG.TAGLINE}`;
    return {success:true,url:buildWaUrl(student.data.NO_WA,msg),message:msg};
  }catch(e){return {success:false,message:e.message};}
}
