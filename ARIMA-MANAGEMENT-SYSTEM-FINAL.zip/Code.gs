/**
 * Entry point + common web helpers.
 */
function doGet() {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle(CONFIG.APP_NAME)
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function getLogoData() {
  return getSetting('LOGO_DATA') || '';
}

function getAppInfo() {
  return {
    appName: CONFIG.APP_NAME,
    companyName: CONFIG.COMPANY_NAME,
    tagline: CONFIG.TAGLINE,
    timezone: CONFIG.TIMEZONE,
    logo: getLogoData()
  };
}

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('ARIMA MANAGEMENT')
    .addItem('Setup Database', 'setupDatabase')
    .addItem('Seed Demo Data', 'seedDemoData')
    .addItem('Create/Reset Admin', 'promptCreateAdmin')
    .addToUi();
}

function promptCreateAdmin() {
  const ui = SpreadsheetApp.getUi();
  const id = ui.prompt('Admin ID', 'Contoh: ADMIN001', ui.ButtonSet.OK_CANCEL);
  if (id.getSelectedButton() !== ui.Button.OK) return;
  const pass = ui.prompt('Password Admin', 'Masukkan password baru.', ui.ButtonSet.OK_CANCEL);
  if (pass.getSelectedButton() !== ui.Button.OK) return;
  const name = ui.prompt('Nama Admin', 'Nama admin.', ui.ButtonSet.OK_CANCEL);
  if (name.getSelectedButton() !== ui.Button.OK) return;
  const result = createAdmin({userId:id.getResponseText(), password:pass.getResponseText(), name:name.getResponseText()});
  ui.alert(result.message || 'Selesai');
}
